module.exports = {
  reactNativePath: '../../node_modules/react-native',
  project: {
    ios: {},
    android: {},
  },
  assets: ['./assets/fonts'],
};
