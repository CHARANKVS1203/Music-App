const Images = {
  filesImage: require('./files.png'),
  readyImage: require('./ready.png'),
  welcomeImage: require('./welcome.png'),
  youtubeImage: require('./youtube.png'),
};

export default Images;
