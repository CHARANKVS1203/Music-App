# Queue

Array of Songs that yet to be played

# Active

Track object of Current playing song

# History

Array of Played songs

Flow

Add songs to queue -> Queue -> Is there a song playing [ y ] play next [ n ] -> Active -> history

Play song -> active -> history