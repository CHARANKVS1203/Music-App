export type SongProps = { id: string; title: string, artist?: string, album?: string, cover?: string, path: string, duration?: string | number, fileName?: string, liked?: boolean; url?: string };
